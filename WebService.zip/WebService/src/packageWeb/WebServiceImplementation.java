package packageWeb;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;
  
@WebService(endpointInterface="packageWeb.WebServiceInterface")
@SOAPBinding(style = Style.RPC)
public class WebServiceImplementation implements WebServiceInterface {  

	public String get(String username,String password) {
		
		String defaultUser = "user1";
		String defaultPass = "pass1";
		String information ="";
		
		if((username.equals(defaultUser)) && (password.equals(defaultPass))){
		
			 
			String testLocation = "C:/yazilim/test.txt";
			
			
			try(Scanner scanner = new Scanner(new File(testLocation))){
				
				while(scanner.hasNext()){
					information = scanner.nextLine();
					System.out.println(information);
				}
				return information;
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "Exception occured! " + e.getMessage();
			}
			
			
		}
		
		else{
			//System.out.println("Wrong Username or Password, try again");
			return "Wrong Username or Password, try again";
			
		}	
	}
}