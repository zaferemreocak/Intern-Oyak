package packageWeb;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.ws.Service;
import javax.xml.namespace.QName;

public class WebServiceClient {
	public static void main(String[] args) throws MalformedURLException {
		String username 		= "user1";
		String password		 	= "pass1";
		
		
		
		URL url = new URL("http://localhost:8080/WebService?wsdl");
		QName qname = new QName("http://packageWeb/","WebServiceImplementationService");
		Service service = Service.create(url,qname);
		WebServiceInterface webservice = service.getPort(WebServiceInterface.class);
		String deger = webservice.get(username, password);
		System.out.println("WEBSERVIS DONUS DEGERI " + deger);
	}
}