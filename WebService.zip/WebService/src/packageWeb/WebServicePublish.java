package packageWeb;
import javax.xml.ws.Endpoint;

public class WebServicePublish {
	public static void main(String[] args) {
		Endpoint endpoint = Endpoint.publish("http://localhost:8080/WebService", new WebServiceImplementation());
		System.out.println(endpoint.isPublished());
	}
}